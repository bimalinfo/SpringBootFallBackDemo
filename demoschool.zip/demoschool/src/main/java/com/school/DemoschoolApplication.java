package com.school;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoschoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoschoolApplication.class, args);
	}

}
